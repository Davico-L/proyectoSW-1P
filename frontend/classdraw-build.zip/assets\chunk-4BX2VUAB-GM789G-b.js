import{_ as l}from"./mermaid-to-excalidraw-BXQDVhp8.js";function m(e,c){var i,t,o;e.accDescr&&((i=c.setAccDescription)==null||i.call(c,e.accDescr)),e.accTitle&&((t=c.setAccTitle)==null||t.call(c,e.accTitle)),e.title&&((o=c.setDiagramTitle)==null||o.call(c,e.title))}l(m,"populateCommonDb");export{m as p};
//# sourceMappingURL=chunk-4BX2VUAB-GM789G-b.js.map
