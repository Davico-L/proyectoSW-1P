import{_ as a,d as o}from"./mermaid-to-excalidraw-BXQDVhp8.js";var d=a((t,e)=>{let n;return e==="sandbox"&&(n=o("#i"+t)),(e==="sandbox"?o(n.nodes()[0].contentDocument.body):o("body")).select(`[id="${t}"]`)},"getDiagramElement");export{d as g};
//# sourceMappingURL=chunk-55IACEB6-Cj3PrqLU.js.map
